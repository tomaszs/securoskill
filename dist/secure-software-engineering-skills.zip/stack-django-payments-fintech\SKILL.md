---
name: stack-django-payments-fintech
description: >-
  Implements security-payments-fintech rules using Django. Use when building or reviewing Django code for payments and financial flows.
disable-model-invocation: true
---

# Django: Payments and financial flows

## When to use

You are working in **Django** and need concrete guidance for **payments and financial flows**.

1. Load domain skill `security-payments-fintech` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Django** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
