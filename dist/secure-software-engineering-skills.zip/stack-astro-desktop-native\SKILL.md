---
name: stack-astro-desktop-native
description: >-
  Implements security-desktop-native rules using Astro. Use when building or reviewing Astro code for desktop and native application security.
disable-model-invocation: true
---

# Astro: Desktop and native application security

## When to use

You are working in **Astro** and need concrete guidance for **desktop and native application security**.

1. Load domain skill `security-desktop-native` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Astro** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
