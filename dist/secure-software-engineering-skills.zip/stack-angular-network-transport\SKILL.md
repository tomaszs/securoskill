---
name: stack-angular-network-transport
description: >-
  Implements security-network-transport rules using Angular. Use when building or reviewing Angular code for network and transport security.
disable-model-invocation: true
---

# Angular: Network and transport security

## When to use

You are working in **Angular** and need concrete guidance for **network and transport security**.

1. Load domain skill `security-network-transport` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Angular** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in Angular**.
3. Confirm verification steps before merge.
