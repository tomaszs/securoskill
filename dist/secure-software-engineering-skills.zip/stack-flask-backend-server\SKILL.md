---
name: stack-flask-backend-server
description: >-
  Implements security-backend-server rules using Flask. Use when building or reviewing Flask code for backend and server-side security.
disable-model-invocation: true
---

# Flask: Backend and server-side security

## When to use

You are working in **Flask** and need concrete guidance for **backend and server-side security**.

1. Load domain skill `security-backend-server` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Flask** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
