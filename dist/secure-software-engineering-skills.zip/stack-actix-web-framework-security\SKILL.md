---
name: stack-actix-web-framework-security
description: >-
  Implements security-web-framework-security rules using Actix Web (Rust). Use when building or reviewing Actix Web (Rust) code for web ui framework security.
disable-model-invocation: true
---

# Actix Web (Rust): Web UI framework security

## When to use

You are working in **Actix Web (Rust)** and need concrete guidance for **web ui framework security**.

1. Load domain skill `security-web-framework-security` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Actix Web (Rust)** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in Actix Web (Rust)**.
3. Confirm verification steps before merge.
