---
name: stack-docker-identity-access
description: >-
  Implements security-identity-access rules using Docker. Use when building or reviewing Docker code for identity, authentication, and access control.
disable-model-invocation: true
---

# Docker: Identity, authentication, and access control

## When to use

You are working in **Docker** and need concrete guidance for **identity, authentication, and access control**.

1. Load domain skill `security-identity-access` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Docker** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
