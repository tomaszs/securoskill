---
name: stack-aspnet-core-web-framework-security
description: >-
  Implements security-web-framework-security rules using ASP.NET Core. Use when building or reviewing ASP.NET Core code for web ui framework security.
disable-model-invocation: true
---

# ASP.NET Core: Web UI framework security

## When to use

You are working in **ASP.NET Core** and need concrete guidance for **web ui framework security**.

1. Load domain skill `security-web-framework-security` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **ASP.NET Core** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in ASP.NET Core**.
3. Confirm verification steps before merge.
