---
name: stack-aspnet-core-realtime-messaging
description: >-
  Implements security-realtime-messaging rules using ASP.NET Core. Use when building or reviewing ASP.NET Core code for real-time, websocket, and messaging.
disable-model-invocation: true
---

# ASP.NET Core: Real-time, WebSocket, and messaging

## When to use

You are working in **ASP.NET Core** and need concrete guidance for **real-time, websocket, and messaging**.

1. Load domain skill `security-realtime-messaging` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **ASP.NET Core** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in ASP.NET Core**.
3. Confirm verification steps before merge.
