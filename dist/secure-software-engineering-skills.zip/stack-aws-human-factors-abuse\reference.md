# Amazon Web Services: Human factors, social engineering, and support abuse

Stack-specific implementation for **Amazon Web Services** (Cloud). Normative rules: domain skill `security-human-factors-abuse` / `reference.md`.

## Developer phishing

**Sub-topics:** Fake npm, Malicious PR, Stolen OAuth, Slack DMs, Fake CI notifications

### Platform rules (summary)

- Validate and canonicalize all inputs touching Developer phishing; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Developer phishing.
- Keep dependencies patched; pin versions for Developer phishing components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Developer phishing before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Developer phishing paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Customer support takeover

**Sub-topics:** Security questions, SIM swap, Email change, Manual password reset, VIP support

### Platform rules (summary)

- Validate and canonicalize all inputs touching Customer support takeover; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Customer support takeover.
- Keep dependencies patched; pin versions for Customer support takeover components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Customer support takeover before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Customer support takeover paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Vishing and impersonation

**Sub-topics:** CEO fraud, Vendor impersonation, Callback phishing, Deepfake calls, Help desk pressure

### Platform rules (summary)

- Validate and canonicalize all inputs touching Vishing and impersonation; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Vishing and impersonation.
- Keep dependencies patched; pin versions for Vishing and impersonation components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Vishing and impersonation before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Vishing and impersonation paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Insider threat

**Sub-topics:** Offboarding gaps, Privileged monitoring, Data exfil jobs, Sabotage, Whistleblower channels

### Platform rules (summary)

- Validate and canonicalize all inputs touching Insider threat; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Insider threat.
- Keep dependencies patched; pin versions for Insider threat components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Insider threat before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Insider threat paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Physical access to dev assets

**Sub-topics:** Unattended laptops, USB drops, Office tailgating, Printer rooms, Hardware tokens

### Platform rules (summary)

- Validate and canonicalize all inputs touching Physical access to dev assets; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Physical access to dev assets.
- Keep dependencies patched; pin versions for Physical access to dev assets components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Physical access to dev assets before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Physical access to dev assets paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Security awareness

**Sub-topics:** Phishing sims, Report buttons, Metrics, Role-based training, Contractors

### Platform rules (summary)

- Validate and canonicalize all inputs touching Security awareness; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Security awareness.
- Keep dependencies patched; pin versions for Security awareness components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Security awareness before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Security awareness paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Incident communications

**Sub-topics:** Status page accuracy, Rumor control, Legal hold comms, Customer notification, Media leaks

### Platform rules (summary)

- Validate and canonicalize all inputs touching Incident communications; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Incident communications.
- Keep dependencies patched; pin versions for Incident communications components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Incident communications before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Incident communications paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Bug bounty operations

**Sub-topics:** Researcher relations, Safe harbor, Duplicate handling, SLA payouts, Disclosure timelines

### Platform rules (summary)

- Validate and canonicalize all inputs touching Bug bounty operations; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Bug bounty operations.
- Keep dependencies patched; pin versions for Bug bounty operations components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Bug bounty operations before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Bug bounty operations paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Law enforcement requests

**Sub-topics:** Subpoena validation, Emergency disclosure, Transparency reports, User notice, National security

### Platform rules (summary)

- Validate and canonicalize all inputs touching Law enforcement requests; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Law enforcement requests.
- Keep dependencies patched; pin versions for Law enforcement requests components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Law enforcement requests before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Law enforcement requests paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Social engineering of login flows

**Sub-topics:** Fake OAuth apps, Consent screen tricks, Passwordless confusion, Magic link forwarding, QR login

### Platform rules (summary)

- Validate and canonicalize all inputs touching Social engineering of login flows; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Social engineering of login flows.
- Keep dependencies patched; pin versions for Social engineering of login flows components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Social engineering of login flows before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Social engineering of login flows paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## Documentation and wiki leaks

**Sub-topics:** Public Confluence, Pastebin creds, Runbooks with secrets, Architecture diagrams, Zoom recordings

### Platform rules (summary)

- Validate and canonicalize all inputs touching Documentation and wiki leaks; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to Documentation and wiki leaks.
- Keep dependencies patched; pin versions for Documentation and wiki leaks components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for Documentation and wiki leaks before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for Documentation and wiki leaks paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

## BPO and outsourced access

**Sub-topics:** VPN accounts, Time-bound access, Screen monitoring, Data handling, Contract clauses

### Platform rules (summary)

- Validate and canonicalize all inputs touching BPO and outsourced access; never trust client-side checks alone.
- Use parameterized queries / safe APIs; avoid string concatenation for queries and commands.
- Encode output appropriately for the sink (HTML, URL, JS, SQL) relevant to BPO and outsourced access.
- Keep dependencies patched; pin versions for BPO and outsourced access components.

### How to do this in Amazon Web Services

- Read normative rules in domain skill `security-human-factors-abuse` / `reference.md`, then apply them using Amazon Web Services APIs and deployment model.
- Prefer framework-maintained security features in Amazon Web Services over custom crypto, auth, or parsers.
- Add stack-appropriate tests (unit + integration) for BPO and outsourced access before merge.
- Pin Amazon Web Services dependencies; monitor CVE advisories for your stack.

### Verify

- Add automated tests for BPO and outsourced access paths in Amazon Web Services.
- Run SAST/dependency scan configured for Cloud.

