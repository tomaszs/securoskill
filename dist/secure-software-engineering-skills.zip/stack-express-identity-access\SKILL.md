---
name: stack-express-identity-access
description: >-
  Implements security-identity-access rules using Express.js. Use when building or reviewing Express.js code for identity, authentication, and access control.
disable-model-invocation: true
---

# Express.js: Identity, authentication, and access control

## When to use

You are working in **Express.js** and need concrete guidance for **identity, authentication, and access control**.

1. Load domain skill `security-identity-access` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Express.js** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
