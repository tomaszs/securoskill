---
name: stack-angular-zero-trust-access
description: >-
  Implements security-zero-trust-access rules using Angular. Use when building or reviewing Angular code for zero trust and secure access.
disable-model-invocation: true
---

# Angular: Zero trust and secure access

## When to use

You are working in **Angular** and need concrete guidance for **zero trust and secure access**.

1. Load domain skill `security-zero-trust-access` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Angular** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in Angular**.
3. Confirm verification steps before merge.
