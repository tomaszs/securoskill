---
name: stack-docker-zero-trust-access
description: >-
  Implements security-zero-trust-access rules using Docker. Use when building or reviewing Docker code for zero trust and secure access.
disable-model-invocation: true
---

# Docker: Zero trust and secure access

## When to use

You are working in **Docker** and need concrete guidance for **zero trust and secure access**.

1. Load domain skill `security-zero-trust-access` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Docker** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
