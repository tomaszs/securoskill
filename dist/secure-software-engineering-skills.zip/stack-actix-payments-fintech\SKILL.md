---
name: stack-actix-payments-fintech
description: >-
  Implements security-payments-fintech rules using Actix Web (Rust). Use when building or reviewing Actix Web (Rust) code for payments and financial flows.
disable-model-invocation: true
---

# Actix Web (Rust): Payments and financial flows

## When to use

You are working in **Actix Web (Rust)** and need concrete guidance for **payments and financial flows**.

1. Load domain skill `security-payments-fintech` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Actix Web (Rust)** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in Actix Web (Rust)**.
3. Confirm verification steps before merge.
