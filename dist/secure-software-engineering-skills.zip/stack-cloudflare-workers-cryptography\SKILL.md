---
name: stack-cloudflare-workers-cryptography
description: >-
  Implements security-cryptography rules using Cloudflare Workers. Use when building or reviewing Cloudflare Workers code for cryptography and key management.
disable-model-invocation: true
---

# Cloudflare Workers: Cryptography and key management

## When to use

You are working in **Cloudflare Workers** and need concrete guidance for **cryptography and key management**.

1. Load domain skill `security-cryptography` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Cloudflare Workers** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
