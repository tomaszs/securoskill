---
name: stack-express-ai-ml-security
description: >-
  Implements security-ai-ml-security rules using Express.js. Use when building or reviewing Express.js code for ai and ml system security.
disable-model-invocation: true
---

# Express.js: AI and ML system security

## When to use

You are working in **Express.js** and need concrete guidance for **ai and ml system security**.

1. Load domain skill `security-ai-ml-security` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Express.js** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
