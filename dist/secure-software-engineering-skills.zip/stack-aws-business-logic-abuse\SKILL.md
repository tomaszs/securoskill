---
name: stack-aws-business-logic-abuse
description: >-
  Implements security-business-logic-abuse rules using Amazon Web Services. Use when building or reviewing Amazon Web Services code for business logic and abuse prevention.
disable-model-invocation: true
---

# Amazon Web Services: Business logic and abuse prevention

## When to use

You are working in **Amazon Web Services** and need concrete guidance for **business logic and abuse prevention**.

1. Load domain skill `security-business-logic-abuse` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Amazon Web Services** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
