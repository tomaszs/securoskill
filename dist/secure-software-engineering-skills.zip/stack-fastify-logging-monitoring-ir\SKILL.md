---
name: stack-fastify-logging-monitoring-ir
description: >-
  Implements security-logging-monitoring-ir rules using Fastify. Use when building or reviewing Fastify code for logging, monitoring, and incident response.
disable-model-invocation: true
---

# Fastify: Logging, monitoring, and incident response

## When to use

You are working in **Fastify** and need concrete guidance for **logging, monitoring, and incident response**.

1. Load domain skill `security-logging-monitoring-ir` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Fastify** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
