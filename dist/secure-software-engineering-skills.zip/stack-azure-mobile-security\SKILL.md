---
name: stack-azure-mobile-security
description: >-
  Implements security-mobile-security rules using Microsoft Azure. Use when building or reviewing Microsoft Azure code for mobile application security.
disable-model-invocation: true
---

# Microsoft Azure: Mobile application security

## When to use

You are working in **Microsoft Azure** and need concrete guidance for **mobile application security**.

1. Load domain skill `security-mobile-security` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Microsoft Azure** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
