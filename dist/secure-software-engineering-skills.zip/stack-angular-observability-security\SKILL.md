---
name: stack-angular-observability-security
description: >-
  Implements security-observability-security rules using Angular. Use when building or reviewing Angular code for observability and debugging security.
disable-model-invocation: true
---

# Angular: Observability and debugging security

## When to use

You are working in **Angular** and need concrete guidance for **observability and debugging security**.

1. Load domain skill `security-observability-security` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Angular** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
