---
name: stack-cloudflare-workers-human-factors-abuse
description: >-
  Implements security-human-factors-abuse rules using Cloudflare Workers. Use when building or reviewing Cloudflare Workers code for human factors, social engineering, and support abuse.
disable-model-invocation: true
---

# Cloudflare Workers: Human factors, social engineering, and support abuse

## When to use

You are working in **Cloudflare Workers** and need concrete guidance for **human factors, social engineering, and support abuse**.

1. Load domain skill `security-human-factors-abuse` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Cloudflare Workers** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
