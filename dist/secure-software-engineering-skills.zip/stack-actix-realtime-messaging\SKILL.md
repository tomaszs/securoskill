---
name: stack-actix-realtime-messaging
description: >-
  Implements security-realtime-messaging rules using Actix Web (Rust). Use when building or reviewing Actix Web (Rust) code for real-time, websocket, and messaging.
disable-model-invocation: true
---

# Actix Web (Rust): Real-time, WebSocket, and messaging

## When to use

You are working in **Actix Web (Rust)** and need concrete guidance for **real-time, websocket, and messaging**.

1. Load domain skill `security-realtime-messaging` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Actix Web (Rust)** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
