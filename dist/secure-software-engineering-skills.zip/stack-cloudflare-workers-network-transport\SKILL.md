---
name: stack-cloudflare-workers-network-transport
description: >-
  Implements security-network-transport rules using Cloudflare Workers. Use when building or reviewing Cloudflare Workers code for network and transport security.
disable-model-invocation: true
---

# Cloudflare Workers: Network and transport security

## When to use

You are working in **Cloudflare Workers** and need concrete guidance for **network and transport security**.

1. Load domain skill `security-network-transport` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Cloudflare Workers** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
