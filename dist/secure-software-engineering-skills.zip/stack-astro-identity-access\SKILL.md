---
name: stack-astro-identity-access
description: >-
  Implements security-identity-access rules using Astro. Use when building or reviewing Astro code for identity, authentication, and access control.
disable-model-invocation: true
---

# Astro: Identity, authentication, and access control

## When to use

You are working in **Astro** and need concrete guidance for **identity, authentication, and access control**.

1. Load domain skill `security-identity-access` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Astro** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in Astro**.
3. Confirm verification steps before merge.
