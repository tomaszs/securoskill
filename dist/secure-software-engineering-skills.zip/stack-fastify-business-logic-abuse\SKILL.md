---
name: stack-fastify-business-logic-abuse
description: >-
  Implements security-business-logic-abuse rules using Fastify. Use when building or reviewing Fastify code for business logic and abuse prevention.
disable-model-invocation: true
---

# Fastify: Business logic and abuse prevention

## When to use

You are working in **Fastify** and need concrete guidance for **business logic and abuse prevention**.

1. Load domain skill `security-business-logic-abuse` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Fastify** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
