---
name: stack-actix-frontend-client
description: >-
  Implements security-frontend-client rules using Actix Web (Rust). Use when building or reviewing Actix Web (Rust) code for frontend and client-side security.
disable-model-invocation: true
---

# Actix Web (Rust): Frontend and client-side security

## When to use

You are working in **Actix Web (Rust)** and need concrete guidance for **frontend and client-side security**.

1. Load domain skill `security-frontend-client` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Actix Web (Rust)** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Implement using stack-specific bullets under **How to do this in Actix Web (Rust)**.
3. Confirm verification steps before merge.
