---
name: stack-azure-containers-k8s
description: >-
  Implements security-containers-k8s rules using Microsoft Azure. Use when building or reviewing Microsoft Azure code for containers and kubernetes.
disable-model-invocation: true
---

# Microsoft Azure: Containers and Kubernetes

## When to use

You are working in **Microsoft Azure** and need concrete guidance for **containers and kubernetes**.

1. Load domain skill `security-containers-k8s` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Microsoft Azure** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
