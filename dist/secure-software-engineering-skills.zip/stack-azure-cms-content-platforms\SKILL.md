---
name: stack-azure-cms-content-platforms
description: >-
  Implements security-cms-content-platforms rules using Microsoft Azure. Use when building or reviewing Microsoft Azure code for cms, content platforms, and publishing.
disable-model-invocation: true
---

# Microsoft Azure: CMS, content platforms, and publishing

## When to use

You are working in **Microsoft Azure** and need concrete guidance for **cms, content platforms, and publishing**.

1. Load domain skill `security-cms-content-platforms` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Microsoft Azure** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
