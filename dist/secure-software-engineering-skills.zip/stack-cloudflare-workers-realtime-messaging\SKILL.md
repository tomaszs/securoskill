---
name: stack-cloudflare-workers-realtime-messaging
description: >-
  Implements security-realtime-messaging rules using Cloudflare Workers. Use when building or reviewing Cloudflare Workers code for real-time, websocket, and messaging.
disable-model-invocation: true
---

# Cloudflare Workers: Real-time, WebSocket, and messaging

## When to use

You are working in **Cloudflare Workers** and need concrete guidance for **real-time, websocket, and messaging**.

1. Load domain skill `security-realtime-messaging` for policy and full rule layers.
2. Use [reference.md](reference.md) here for **Cloudflare Workers** APIs and patterns.

## Workflow

1. Match your feature to sub-areas in `reference.md`.
2. Follow **Do** / **Don't** lists in `reference.md` for this stack.
3. Confirm **Verify** steps before merge.
